export let func = ():void=>{
    console.log("Hello Ahsen")
}
