import { func } from "./service";
func()